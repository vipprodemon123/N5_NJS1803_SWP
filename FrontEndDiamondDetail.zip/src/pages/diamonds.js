import React from 'react'

export default function Diamonds() {
  return (
    <div>This is Diamond List</div>
  )
}
