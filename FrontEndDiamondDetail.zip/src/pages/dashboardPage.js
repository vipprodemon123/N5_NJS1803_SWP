import React from 'react'
import Dashboard from '../components/dashboard/Dashboard'
export default function dashboardPage() {
  return (
    <div>
        <Dashboard />
    </div>
  )
}
