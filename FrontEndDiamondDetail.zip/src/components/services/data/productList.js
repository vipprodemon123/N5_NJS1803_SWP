const pic1 = 'assets/images/cathedral_ER.png'
export const Products = [
    {
        image: pic1,
        name: 'Nhẫn cầu hôn Love of Swan NCH0037',
        price: '12.308.000',
        oldPrice: '14.480.000',
        colors: ['#D4AF37', '#C0C0C0', '#E5E4E2'],
        id: 1,
    },
    {
        image: pic1,
        name: 'Nhẫn cầu hôn solitaire Water Lily NCH1003',
        price: '10.591.000',
        oldPrice: '12.460.000',
        colors: ['#D4AF37', '#C0C0C0', '#E5E4E2'],
        id: 2

    },
    {
        image: pic1,
        name: 'Nhẫn cầu hôn Solitaire Love Shine NCH1004',
        price: '14.679.500',
        oldPrice: '17.970.000',
        colors: ['#D4AF37', '#C0C0C0', '#E5E4E2'],
        id: 3
    },
    {
        image: pic1,
        name: 'Nhẫn cầu hôn Solitaire Primrose flower NCH1005',
        price: '12.359.000',
        oldPrice: '14.540.000',
        colors: ['#D4AF37', '#C0C0C0', '#E5E4E2'],
        id: 4
    },
    {
        image: pic1,
        name: 'Nhẫn cầu hôn Solitaire Double Heart NCH1007',
        price: '10.302.000',
        oldPrice: '12.080.000',
        colors: ['#D4AF37', '#C0C0C0', '#E5E4E2'],
        id: 5
    },
    // {
    //     image: pic1,
    //     name: 'Nhẫn cầu hôn Solitaire Roselle Hibiscus NCH1010',
    //     price: '9.596.500',
    //     oldPrice: '12.080.000',
    //     colors: ['#D4AF37', '#C0C0C0', '#E5E4E2']
    // },
    // {
    //     image: pic1,
    //     name: 'Nhẫn cầu hôn Love of Swan NCH0037',
    //     price: '12.308.000',
    //     oldPrice: '14.480.000',
    //     colors: ['#D4AF37', '#C0C0C0', '#E5E4E2']
    // },
    // {
    //     image: pic1,
    //     name: 'Nhẫn cầu hôn solitaire Water Lily NCH1003',
    //     price: '10.591.000',
    //     oldPrice: '12.460.000',
    //     colors: ['#D4AF37', '#C0C0C0', '#E5E4E2']
    // },
    // {
    //     image: pic1,
    //     name: 'Nhẫn cầu hôn Solitaire Love Shine NCH1004',
    //     price: '14.679.500',
    //     oldPrice: '17.970.000',
    //     colors: ['#D4AF37', '#C0C0C0', '#E5E4E2']
    // },
    // {
    //     image: pic1,
    //     name: 'Nhẫn cầu hôn Solitaire Primrose flower NCH1005',
    //     price: '12.359.000',
    //     oldPrice: '14.540.000',
    //     colors: ['#D4AF37', '#C0C0C0', '#E5E4E2']
    // },
    // {
    //     image: pic1,
    //     name: 'Nhẫn cầu hôn Solitaire Double Heart NCH1007',
    //     price: '10.302.000',
    //     oldPrice: '12.080.000',
    //     colors: ['#D4AF37', '#C0C0C0', '#E5E4E2']
    // },
    // {
    //     image: pic1,
    //     name: 'Nhẫn cầu hôn Solitaire Roselle Hibiscus NCH1010',
    //     price: '9.596.500',
    //     oldPrice: '12.080.000',
    //     colors: ['#D4AF37', '#C0C0C0', '#E5E4E2']
    // },
    // {
    //     image: pic1,
    //     name: 'Nhẫn cầu hôn Love of Swan NCH0037',
    //     price: '12.308.000',
    //     oldPrice: '14.480.000',
    //     colors: ['#D4AF37', '#C0C0C0', '#E5E4E2']
    // },
    // {
    //     image: pic1,
    //     name: 'Nhẫn cầu hôn solitaire Water Lily NCH1003',
    //     price: '10.591.000',
    //     oldPrice: '12.460.000',
    //     colors: ['#D4AF37', '#C0C0C0', '#E5E4E2']
    // },
    // {
    //     image: pic1,
    //     name: 'Nhẫn cầu hôn Solitaire Love Shine NCH1004',
    //     price: '14.679.500',
    //     oldPrice: '17.970.000',
    //     colors: ['#D4AF37', '#C0C0C0', '#E5E4E2']
    // },
    // {
    //     image: pic1,
    //     name: 'Nhẫn cầu hôn Solitaire Primrose flower NCH1005',
    //     price: '12.359.000',
    //     oldPrice: '14.540.000',
    //     colors: ['#D4AF37', '#C0C0C0', '#E5E4E2']
    // },
    // {
    //     image: pic1,
    //     name: 'Nhẫn cầu hôn Solitaire Double Heart NCH1007',
    //     price: '10.302.000',
    //     oldPrice: '12.080.000',
    //     colors: ['#D4AF37', '#C0C0C0', '#E5E4E2']
    // },
    // {
    //     image: pic1,
    //     name: 'Nhẫn cầu hôn Solitaire Roselle Hibiscus NCH1010',
    //     price: '9.596.500',
    //     oldPrice: '12.080.000',
    //     colors: ['#D4AF37', '#C0C0C0', '#E5E4E2']
    // },
];