import React, { useState, useEffect } from 'react';
import {
    Container,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Paper,
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    Tabs,
    Tab,
    AppBar,
    IconButton,
    TextField
} from '@mui/material';
import { Edit, Delete } from '@mui/icons-material';
import './EventPage.css';

const EventPage = () => {
    const [tabIndex, setTabIndex] = useState(0);
    const [open, setOpen] = useState(false);
    const [editingItem, setEditingItem] = useState(null);
    const [promotions, setPromotions] = useState([]);
    const [pointsInfo, setPointsInfo] = useState({
        description: "",
        rules: []
    });

    const handleTabChange = (event, newValue) => {
        setTabIndex(newValue);
    };

    const handleOpen = (item) => {
        setEditingItem(item);
        setOpen(true);
    };

    const handleClose = () => {
        setEditingItem(null);
        setOpen(false);
    };

    const fetchPromotions = async () => {
        try {
            const response = await fetch('https://localhost:7251/api/Promotions');
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const data = await response.json();
            setPromotions(data);
        } catch (error) {
            console.log('Error fetching promotions', error);
        }
    };

    const fetchPointsInfo = async () => {
        try {
            const response = await fetch('https://localhost:7251/api/PointsInfo');
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const data = await response.json();
            setPointsInfo(data);
        } catch (error) {
            console.log('Error fetching points info', error);
        }
    };

    useEffect(() => {
        fetchPromotions();
        fetchPointsInfo();
    }, []);

    const handleSave = async () => {
        try {
            if (tabIndex === 0) {
                // Handling Promotions Save
                if (editingItem.id) {
                    await fetch(`https://localhost:7251/api/Promotions/${editingItem.id}`, {
                        method: 'PUT',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(editingItem)
                    });
                } else {
                    await fetch('https://localhost:7251/api/Promotions', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(editingItem)
                    });
                }
                fetchPromotions();
            } else {
                // Handling Points Info Save
                await fetch('https://localhost:7251/api/PointsInfo', {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(pointsInfo)
                });
                fetchPointsInfo();
            }
            handleClose();
        } catch (error) {
            console.log('Error saving item', error);
        }
    };

    const handleDelete = async (id) => {
        try {
            if (tabIndex === 0) {
                // Delete promotion
                const response = await fetch(`https://localhost:7251/api/Promotions/${id}`, {
                    method: 'DELETE'
                });
                if (!response.ok) {
                    throw new Error(`Failed to delete promotion with id ${id}`);
                }
                fetchPromotions();
            }
        } catch (error) {
            console.log('Error deleting item', error);
        }
    };

    return (
        <div className="event-page">
            <AppBar position="static">
                <Tabs value={tabIndex} onChange={handleTabChange} variant="fullWidth">
                    <Tab label="Promotions" />
                    <Tab label="Points Info" />
                </Tabs>
            </AppBar>

            {tabIndex === 0 && (
                <TableContainer component={Paper} className="table-container">
                    <Table>
                        <TableHead>
                            <TableRow>
                                <TableCell align="center">ID</TableCell>
                                <TableCell align="center">Title</TableCell>
                                <TableCell align="center">Date</TableCell>
                                <TableCell align="center">Discount</TableCell>
                                <TableCell align="center">Description</TableCell>
                                <TableCell align="center">Location</TableCell>
                                <TableCell align="center">Actions</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {promotions.map((promotion) => (
                                <TableRow key={promotion.id}>
                                    <TableCell align="center">{promotion.id}</TableCell>
                                    <TableCell align="center">{promotion.title}</TableCell>
                                    <TableCell align="center">{promotion.date}</TableCell>
                                    <TableCell align="center">{promotion.discount}</TableCell>
                                    <TableCell align="center">{promotion.description}</TableCell>
                                    <TableCell align="center">{promotion.location}</TableCell>
                                    <TableCell align="center">
                                        <IconButton onClick={() => handleOpen(promotion)}>
                                            <Edit />
                                        </IconButton>
                                        <IconButton onClick={() => handleDelete(promotion.id)}>
                                            <Delete />
                                        </IconButton>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </TableContainer>
            )}
            {tabIndex === 1 && (
                <div className="points-info">
                    <TextField
                        margin="dense"
                        label="Description"
                        type="text"
                        fullWidth
                        value={pointsInfo.description}
                        onChange={(e) => setPointsInfo({ ...pointsInfo, description: e.target.value })}
                    />
                    <ul>
                        {pointsInfo.rules.map((rule, index) => (
                            <li key={index}>
                                {rule} <Button onClick={() => {
                                    const newRules = [...pointsInfo.rules];
                                    newRules.splice(index, 1);
                                    setPointsInfo({ ...pointsInfo, rules: newRules });
                                }}>Delete</Button>
                            </li>
                        ))}
                    </ul>
                    <TextField
                        margin="dense"
                        label="New Rule"
                        type="text"
                        fullWidth
                        onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                                setPointsInfo({
                                    ...pointsInfo,
                                    rules: [...pointsInfo.rules, e.target.value]
                                });
                                e.target.value = '';
                            }
                        }}
                    />
                </div>
            )}

            <div className="add-event-button">
                <Button variant="contained" color="primary" onClick={() => handleOpen(null)}>
                    Add {tabIndex === 0 ? 'Promotion' : 'Rule'}
                </Button>
            </div>
            <Dialog open={open} onClose={handleClose}>
                <DialogTitle>{editingItem?.id ? 'Edit Item' : 'Add Item'}</DialogTitle>
                <DialogContent>
                    {tabIndex === 0 && (
                        <>
                            <TextField
                                margin="dense"
                                label="Title"
                                type="text"
                                fullWidth
                                value={editingItem?.title || ''}
                                onChange={(e) => setEditingItem({ ...editingItem, title: e.target.value })}
                            />
                            <TextField
                                margin="dense"
                                label="Date"
                                type="date"
                                fullWidth
                                value={editingItem?.date || ''}
                                onChange={(e) => setEditingItem({ ...editingItem, date: e.target.value })}
                            />
                            <TextField
                                margin="dense"
                                label="Discount"
                                type="text"
                                fullWidth
                                value={editingItem?.discount || ''}
                                onChange={(e) => setEditingItem({ ...editingItem, discount: e.target.value })}
                            />
                            <TextField
                                margin="dense"
                                label="Description"
                                type="text"
                                fullWidth
                                value={editingItem?.description || ''}
                                onChange={(e) => setEditingItem({ ...editingItem, description: e.target.value })}
                            />
                            <TextField
                                margin="dense"
                                label="Location"
                                type="text"
                                fullWidth
                                value={editingItem?.location || ''}
                                onChange={(e) => setEditingItem({ ...editingItem, location: e.target.value })}
                            />
                        </>
                    )}
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleClose} color="primary">
                        Cancel
                    </Button>
                    <Button onClick={handleSave} color="primary">
                        Save
                    </Button>
                </DialogActions>
            </Dialog>
        </div>
    );
};

export default EventPage;
