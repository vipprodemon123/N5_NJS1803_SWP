import React from 'react'
import '../css/thongbao.css'
export default function lichsumuahang() {
  return (
    <div className="notification-page">
        <p>Chưa mua món nào</p>
    </div>
);
}