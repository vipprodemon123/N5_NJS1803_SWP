// src/pages/thongbao.js
import React from 'react';
import '../css/thongbao.css'
export default function ThongBao() {
    return (
        <div className="notification-page">
            <p>Chưa có cập nhật đơn hàng</p>
        </div>
    );
}
